                                              /*
 * DigitalInputs.h
 *
 *  Created on: March 31, 2014

 */

#ifndef DIGITALINPUTS_H_
#define DIGITALINPUTS_H_


typedef unsigned char byte;
typedef unsigned int  uint8;

#define ON          1
#define OFF         0

#endif /* DIGITALINPUTS_H_ */