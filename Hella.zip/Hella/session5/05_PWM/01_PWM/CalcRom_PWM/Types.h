#ifndef PWM_TYPES_H
#define PWM_TYPES_H

typedef unsigned char uint8;


#endif