 #ifndef ADC_1_H
#define ADC_1_H
#include "Types.h"

extern void Adc_Init();
extern void Adc_GetMess(uint8 *Value);


#endif

