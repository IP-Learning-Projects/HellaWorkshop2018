                                              /*
 * AnalogInputs.h
 *
 *  Created on: March 31, 2014

 */

#ifndef ANALOGINPUTS_H_
#define ANALOGINPUTS_H_


typedef unsigned char byte;
typedef unsigned int  uint8;

#define ON          1
#define OFF         0

#endif /* ANALOGINPUTS_H_ */